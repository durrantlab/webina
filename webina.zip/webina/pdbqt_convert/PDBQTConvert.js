var PDBQTConvert = {
    OpenBabel: undefined,

    getFormats: function (conv) {
        try {
            // list all supported input/output formats, use '\n' to separate between each format string
            var sInputFormats = conv.getSupportedInputFormatsStr("\n");
            var sOutputFormats = conv.getSupportedInputFormatsStr("\n");
            console.log(sInputFormats);
            console.log(sOutputFormats);
        } finally {
        }
    },

    convertToPDBQT: function (
        conv,
        inData,
        format,
        includeBranchesTorsions,
        addHydrogens,
        gen3D
    ) {
        // Make the mol file.
        conv.setInFormat("", format); // set input format by file extension
        var mol = new this.OpenBabel.OBMol(); // create a new molecule object...
        conv.readString(mol, inData); // ... and load it with input data

        // Add all hydrogens
        if (addHydrogens === true) {
            mol.AddHydrogensWithParam(false, true, 7.4);
            // for (var i = 1; i <= mol.NumAtoms(); i++) {
            //     mol.AddHydrogens(mol.GetAtom(i))
            // }
        }

        var outData;
        if (gen3D === true) {
            // inData must be in mol format to work with
            // generate3DStructureFromMolData
            conv.setOutFormat("", "mol");
            var molData = conv.writeString(mol, false);

            // Generate 3D coordinates.
            var gen = new this.OpenBabel.OB3DGenWrapper();
            var loopCount = 1;
            for (var i = 0; i < loopCount; ++i) {
                mol = gen.generate3DStructureFromMolData(molData, "MMFF94");
            }
        }

        // Convert to pdbqt
        conv.setOutFormat("", "pdbqt"); // set out format by file extension
        outData = conv.writeString(mol, false); // get output data, do not trim white spaces

        // Delete molecule to free up memory.
        mol.delete();

        // Return pdbqt text.
        return outData;
    },

    convert: function (
        inpText,
        format,
        includeBranchesTorsions,
        addHydrogens,
        gen3D
    ) {
        return new Promise((resolve, reject) => {
            this.OpenBabel = OpenBabelModule().then(() => {
                try {
                    var conv = new this.OpenBabel.ObConversionWrapper(); // create ObConversionWrapper instance
                    var out = this.convertToPDBQT(
                        conv,
                        inpText,
                        format,
                        includeBranchesTorsions,
                        addHydrogens,
                        gen3D
                    );
                    conv.delete(); // free ObConversionWrapper instance

                    resolve(out);
                } catch (err) {
                    if (typeof(err) === "string") {
                        reject(err);
                    } else {
                        reject(err["message"]);
                    }
                }
            });
        });
    },
};

window.PDBQTConvert = PDBQTConvert;
